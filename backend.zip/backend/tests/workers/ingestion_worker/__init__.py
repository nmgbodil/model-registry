"""Tests for ingestion worker components."""
