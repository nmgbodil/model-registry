"""Trustworthy Model Re-use CLI Package."""

# This makes 'src' a Python package.
# You can add package-level initialization here if needed.
