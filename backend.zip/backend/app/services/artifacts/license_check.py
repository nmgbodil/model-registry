# backend/services/license_check.py

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional, Tuple
from urllib.parse import urlparse

import requests
from flask import current_app


class RepoNotFound(Exception):
    """GitHub repository does not exist (404)."""


class ExternalLicenseError(Exception):
    """Could not retrieve or parse external license information."""


@dataclass(frozen=True)
class LicenseInfo:
    """Normalized license info, using SPDX-like identifiers where possible."""
    spdx_id: str


def _parse_github_url(github_url: str) -> Tuple[str, str]:
    """
    Parse a GitHub URL into (owner, repo).

    Accepts URLs like:
      - https://github.com/google-research/bert
      - https://github.com/google-research/bert.git
    """
    parsed = urlparse(github_url)
    if parsed.netloc not in {"github.com", "www.github.com"}:
        raise ValueError("github_url must point to github.com")

    # /owner/repo or /owner/repo/...
    parts = [p for p in parsed.path.split("/") if p]
    if len(parts) < 2:
        raise ValueError("github_url must be of the form https://github.com/<owner>/<repo>")

    owner, repo = parts[0], parts[1]
    if repo.endswith(".git"):
        repo = repo[:-4]
    return owner, repo


def fetch_github_license(github_url: str, *, timeout: float = 5.0) -> LicenseInfo:
    """
    Look up the license for a GitHub repo using the GitHub API.

    We try the /license endpoint first (best), and fall back to the generic repo endpoint.
    Raises:
      - ValueError           for malformed URLs
      - RepoNotFound         if the repo does not exist (404)
      - ExternalLicenseError for other HTTP / parsing / network issues
    """
    try:
        owner, repo = _parse_github_url(github_url)
    except ValueError as exc:
        # Caller will treat this as a 400 Bad Request.
        raise

    base = f"https://api.github.com/repos/{owner}/{repo}"

    try:
        # 1) Try the dedicated license endpoint
        resp = requests.get(f"{base}/license", timeout=timeout)
        if resp.status_code == 404:
            # Maybe the repo exists but license endpoint is not available;
            # we will fall back to the generic repo endpoint next.
            pass
        elif 200 <= resp.status_code < 300:
            data = resp.json()
            license_obj = data.get("license") or {}
            spdx_id = (license_obj.get("spdx_id") or license_obj.get("key") or "").strip()
            if not spdx_id or spdx_id.upper() == "NOASSERTION":
                raise ExternalLicenseError("GitHub did not expose a usable SPDX license id")
            return LicenseInfo(spdx_id=spdx_id.lower())
        else:
            raise ExternalLicenseError(f"GitHub /license endpoint failed: {resp.status_code}")

        # 2) Fallback: generic repo endpoint, which sometimes includes a license key.
        resp = requests.get(base, timeout=timeout)
        if resp.status_code == 404:
            raise RepoNotFound(f"Repository {owner}/{repo} not found")
        if not (200 <= resp.status_code < 300):
            raise ExternalLicenseError(f"GitHub repo endpoint failed: {resp.status_code}")

        data = resp.json()
        license_obj = data.get("license") or {}
        spdx_id = (license_obj.get("spdx_id") or license_obj.get("key") or "").strip()
        if not spdx_id or spdx_id.upper() == "NOASSERTION":
            raise ExternalLicenseError("GitHub did not expose a usable SPDX license id")
        return LicenseInfo(spdx_id=spdx_id.lower())

    except RepoNotFound:
        raise
    except requests.RequestException as exc:
        current_app.logger.exception("Network error while fetching GitHub license")
        raise ExternalLicenseError("Network error while fetching GitHub license") from exc
    except ExternalLicenseError:
        # Already wrapped; just bubble it up.
        raise
    except Exception as exc:  # pragma: no cover - defensive
        current_app.logger.exception("Unexpected error while fetching GitHub license")
        raise ExternalLicenseError("Unexpected error while fetching GitHub license") from exc


def normalize_license_string(raw: Optional[str]) -> Optional[str]:
    """
    Normalize license strings coming from your database into SPDX-ish ids.

    Adjust the mapping as needed to match how licenses are actually stored
    in your Artifacts table.
    """
    if not raw:
        return None

    s = raw.strip().lower()

    mapping = {
        # very common variants
        "mit license": "mit",
        "mit": "mit",
        "apache2": "apache-2.0",
        "apache 2.0": "apache-2.0",
        "apache license 2.0": "apache-2.0",
        "apache-2.0": "apache-2.0",
        "bsd-3-clause": "bsd-3-clause",
        "bsd 3-clause": "bsd-3-clause",
        "bsd 3-clause \"new\" or \"revised\" license": "bsd-3-clause",
        "bsd 2-clause": "bsd-2-clause",
        "gplv3": "gpl-3.0",
        "gpl-3.0": "gpl-3.0",
        "gplv2": "gpl-2.0",
        "gpl-2.0": "gpl-2.0",
        "lgplv3": "lgpl-3.0",
        "lgpl-3.0": "lgpl-3.0",
        "lgpl-2.1": "lgpl-2.1",
        "agpl-3.0": "agpl-3.0",
        "mpl-2.0": "mpl-2.0",
        "epl-2.0": "epl-2.0",
        "unlicense": "unlicense",
        "isc": "isc",
        "cc0-1.0": "cc0-1.0",
        "cc0": "cc0-1.0",
        # you might have things like this in your DB:
        "proprietary": "proprietary",
        "custom": "custom",
    }

    return mapping.get(s, s)


def is_license_compatible_for_finetune_inference(
    model_spdx: str,
    repo_spdx: str,
) -> bool:
    """
    Very simple, conservative compatibility rule for:
       "fine-tune + inference/generation" usage.

    This is *not* a complete legal analysis – it is a pragmatic heuristic inspired by tools
    like ModelGo, good enough for this course project.

    Rules (simplified):
      - Permissive upstream + permissive model => compatible
      - Permissive upstream + weak-copyleft model => compatible (for many scenarios)
      - Strong-copyleft (GPL/AGPL) upstream → treat as *incompatible* unless both sides
        are also strong-copyleft.
      - If either side is "proprietary" or "custom", be conservative and say incompatible.
    """
    s_model = (model_spdx or "").lower()
    s_repo = (repo_spdx or "").lower()

    permissive = {
        "mit",
        "bsd-2-clause",
        "bsd-3-clause",
        "apache-2.0",
        "isc",
        "unlicense",
        "cc0-1.0",
    }

    weak_copyleft = {
        "lgpl-2.1",
        "lgpl-3.0",
        "mpl-2.0",
        "epl-2.0",
    }

    strong_copyleft = {
        "gpl-2.0",
        "gpl-2.0-only",
        "gpl-2.0-or-later",
        "gpl-3.0",
        "gpl-3.0-only",
        "gpl-3.0-or-later",
        "agpl-3.0",
        "agpl-3.0-only",
        "agpl-3.0-or-later",
    }

    if s_model in {"proprietary", "custom"} or s_repo in {"proprietary", "custom"}:
        return False

    # If either is unknown, be conservative and say incompatible.
    if not s_model or not s_repo:
        return False

    # Strong copyleft repo is generally incompatible unless the model is also strong copyleft.
    if s_repo in strong_copyleft and s_model not in strong_copyleft:
        return False

    # Strong copyleft model depending on permissive repo is normally okay (copyleft flows "downstream")
    # but if the repo is proprietary, we already returned False above.

    # Permissive + permissive or permissive + weak-copyleft.
    if (s_repo in permissive or s_repo in weak_copyleft) and (
        s_model in permissive or s_model in weak_copyleft or s_model in strong_copyleft
    ):
        return True

    # Same license family is generally okay.
    if s_model == s_repo:
        return True

    # Fallback: conservative.
    return False
